package com.example.day2cw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2cw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
