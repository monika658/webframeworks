package com.example.day4cw3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4cw3Application {

	public static void main(String[] args) {
		SpringApplication.run(Day4cw3Application.class, args);
	}

}
