package com.example.day2cw3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2cw3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
